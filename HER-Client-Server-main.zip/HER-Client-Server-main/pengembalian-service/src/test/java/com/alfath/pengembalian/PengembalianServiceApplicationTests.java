package com.alfath.pengembalian;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PengembalianServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
