package com.alfath.anggota;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnggotaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
