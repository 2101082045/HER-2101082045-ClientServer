package com.alfath.peminjaman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeminjamanServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
