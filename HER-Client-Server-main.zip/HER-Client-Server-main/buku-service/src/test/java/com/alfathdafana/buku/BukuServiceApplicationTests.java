package com.alfathdafana.buku;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BukuServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
